create definer = root@localhost view vmanchestercity as
select `library`.`member`.`MemberFname` AS `MemberFname`, `library`.`member`.`MemberLname` AS `MemberLname`
from `library`.`member`
where `library`.`member`.`City` = 'Manchester City';

