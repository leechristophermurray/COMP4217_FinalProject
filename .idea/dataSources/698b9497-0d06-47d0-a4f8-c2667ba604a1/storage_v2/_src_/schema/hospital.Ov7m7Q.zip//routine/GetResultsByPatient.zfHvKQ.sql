create
    definer = root@localhost procedure GetResultsByPatient(IN patID int)
BEGIN
        SELECT
               types AS TestType,
               name AS TestName,
                test_result AS TestResult,
                scn_img AS Attatchment,
               pt.dates AS TestDate
        FROM
             performs_test AS pt
             JOIN tests AS t
                ON pt.test_ID = t.test_ID
                    AND pat_ID = patID
            JOIN  generate_results AS gr
                 ON t.test_ID = gr.test_ID
            JOIN results AS r
                ON gr.result_ID = r.result_ID
            LEFT JOIN attached_to AS at
                ON r.result_ID = at.result_ID
            LEFT JOIN scnimg AS si
                ON at.scn_img_ID = si.scn_img_ID;
	    # WHERE pat_ID = patID;
    END;

