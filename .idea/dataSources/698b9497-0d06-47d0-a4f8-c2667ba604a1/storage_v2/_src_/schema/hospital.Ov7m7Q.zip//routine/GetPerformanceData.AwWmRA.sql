create
    definer = root@localhost procedure GetPerformanceData()
BEGIN
        SELECT
               i.doc_ID,
               fname,
               lname,
               COUNT(pat_ID) AS amount,
               last_5_days.dates
        FROM (
            SELECT DISTINCT
                              dates
                FROM performs_treatment
                WHERE dates > CURRENT_DATE() - INTERVAL 5 DAY
            ) AS last_5_days
            LEFT JOIN performs_treatment AS pt
                ON pt.dates = last_5_days.dates
            LEFT JOIN intern AS i
                ON pt.doc_ID = i.doc_ID
            LEFT JOIN doctors d
                ON i.doc_ID = d.doc_ID
        GROUP BY last_5_days.dates,i.doc_ID
        ORDER BY last_5_days.dates DESC, amount DESC;
    END;

