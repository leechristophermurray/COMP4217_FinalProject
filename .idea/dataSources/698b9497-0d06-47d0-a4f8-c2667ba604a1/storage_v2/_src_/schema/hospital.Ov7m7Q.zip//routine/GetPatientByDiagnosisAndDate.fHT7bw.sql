create
    definer = root@localhost procedure GetPatientByDiagnosisAndDate(IN start_date date, IN end_date date, IN diagnosis varchar(100))
BEGIN
        SELECT fname,lname FROM Patients 
            WHERE pat_ID IN(
                    SELECT pat_ID FROM makes_diagnosis
                        WHERE dates BETWEEN start_date AND end_date AND diag_ID IN(
                    SELECT diag_ID FROM Diagnosis AS d
                        WHERE d.name = diagnosis)
                );
    END;

