create
    definer = root@localhost procedure sp_add_nurse(IN fname varchar(100), IN lname varchar(100), IN dob date,
                                                    IN address varchar(500), IN phone int, IN category varchar(100))
BEGIN
        SET @username = CONCAT(fname,lname);
        SET @password = CONCAT(fname,lname);

        IF (SELECT NOT EXISTS(SELECT 1 FROM mysql.user WHERE user = @username)) THEN
            SET @sql = CONCAT('GRANT USAGE,SELECT ON HOSPITAL.* to \'',@username,'\'@\'%\' IDENTIFIED BY \'',@password,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT EXECUTE ON PROCEDURE sp_get_currentuser TO \'',@username,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT EXECUTE ON PROCEDURE sp_get_doctors TO \'',@username,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT EXECUTE ON PROCEDURE get_patients_by_allergens TO \'',@username,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT EXECUTE ON PROCEDURE sp_add_patient TO \'',@username,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT EXECUTE ON PROCEDURE get_patients TO \'',@username,'\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT Nurse TO \'',@username,'\'@\'%\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET @sql = CONCAT('GRANT AppUser TO \'',@username,'\'@\'%\'');
            PREPARE stmt from @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            INSERT INTO Nurses VALUES (NULL, fname, lname, dob, address, phone, category);
        END IF;
    END;

