create
    definer = root@localhost procedure sp_add_patient(IN fname varchar(100), IN lname varchar(100), IN dob date,
                                                      IN address varchar(500), IN phone int)
BEGIN

        IF (SELECT NOT EXISTS(SELECT 1
                                FROM hospital.patients AS p
                                WHERE p.fname = fname
                                AND p.lname = lname
                                AND p.dob = dob
                                AND p.address = address
                                AND p.phone = phone)) THEN

            INSERT INTO Patients VALUES (NULL, fname, lname, dob, address, phone);

        END IF;
    END;

