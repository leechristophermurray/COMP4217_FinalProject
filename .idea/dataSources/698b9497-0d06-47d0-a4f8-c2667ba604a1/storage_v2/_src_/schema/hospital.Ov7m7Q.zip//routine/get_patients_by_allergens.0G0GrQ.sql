create
    definer = root@localhost procedure get_patients_by_allergens()
BEGIN
        SELECT
               pat_ID,
               FirstName,
               LastName,
               Allergen
        FROM
        (SELECT p.pat_ID,
                p.fname      AS FirstName,
                p.lname      AS LastName,
                a.name       AS Allergen
        FROM patients AS p
             JOIN afflicted_with aw ON p.pat_ID = aw.pat_ID
             JOIN otherallergies AS a ON a.allergy_ID = aw.allergy_ID

        UNION

        SELECT p.pat_ID,
               p.fname      AS FirstName,
               p.lname      AS LastName,
               m.gen_name   AS Allergen
        FROM patients AS p
             JOIN allergic_to at ON p.pat_ID = at.pat_ID
             JOIN medication AS m ON m.med_ID = at.med_ID) AS pat_allergens
        ORDER BY pat_ID;
    END;

