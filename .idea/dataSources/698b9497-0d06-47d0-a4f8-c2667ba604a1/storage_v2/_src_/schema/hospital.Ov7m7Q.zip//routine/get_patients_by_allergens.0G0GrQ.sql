create
    definer = root@localhost procedure get_patients_by_allergens()
BEGIN
        SELECT a.name  AS Allergen,
               p.fname  AS FirstName,
               p.lname AS LastName
        FROM patients AS p
                 JOIN afflicted_with aw on p.pat_ID = aw.pat_ID
                 JOIN otherallergies as a on a.allergy_ID = aw.allergy_ID

        UNION

        SELECT m.gen_name AS Allergen,
               p.fname     AS FirstName,
               p.lname    AS LastName
        FROM patients AS p
                 JOIN allergic_to at on p.pat_ID = at.pat_ID
                 JOIN medication as m on m.med_ID = at.med_ID;
    END;

