create
    definer = root@localhost procedure GetMedicineAllergyByMostPatients()
BEGIN
        SELECT
               m.med_ID,
               gen_name,
               risky_medz.pat_count
        FROM Medication AS m
        JOIN (
                SELECT
                       med_ID,
                       COUNT(pat_ID) AS pat_count
                FROM allergic_to
                GROUP BY med_ID
                    HAVING COUNT(pat_ID) > (
                        SELECT
                               AVG(at_avg.Amount)
                        FROM (
                            SELECT
                               COUNT(pat_ID) AS Amount
                            FROM allergic_to
                            GROUP BY med_ID
                            ) AS at_avg
                        )
                ) AS risky_medz
            ON m.med_ID = risky_medz.med_ID
        ORDER BY risky_medz.pat_count DESC
        LIMIT 10;
    END;

