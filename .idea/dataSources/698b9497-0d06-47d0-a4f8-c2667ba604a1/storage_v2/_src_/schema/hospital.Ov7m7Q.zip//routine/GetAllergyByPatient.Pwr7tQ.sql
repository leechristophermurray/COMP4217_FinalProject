create
    definer = root@localhost procedure GetAllergyByPatient(IN first_name varchar(100), IN last_name varchar(100))
BEGIN
        SELECT name FROM OtherAllergies
		    WHERE Allergy_ID IN(
                SELECT allergy_ID FROM afflicted_with
                    WHERE pat_ID IN(
                            SELECT pat_id FROM Patients
                                WHERE fname = first_name and lname = last_name)
		                )
        UNION
        SELECT gen_name FROM Medication
            WHERE med_ID IN(
                SELECT med_ID FROM allergic_to
                    WHERE pat_ID IN(
                            SELECT pat_id FROM Patients
                                WHERE fname = first_name and lname = last_name
                )
        );
    END;

