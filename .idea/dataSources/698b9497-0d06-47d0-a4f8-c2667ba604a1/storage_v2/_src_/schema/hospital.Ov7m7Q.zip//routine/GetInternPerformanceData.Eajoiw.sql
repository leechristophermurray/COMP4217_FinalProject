create
    definer = root@localhost procedure GetInternPerformanceData()
BEGIN
        SELECT
               i.doc_ID,
               fname,
               lname,
               COUNT(pat_ID) AS amount,
               last_7_days.dates
        FROM (
            SELECT DISTINCT
                              dates
                FROM performs_treatment
                WHERE dates > CURRENT_DATE() - INTERVAL 7 DAY
            ) AS last_7_days
            LEFT JOIN performs_treatment AS pt
                ON pt.dates = last_7_days.dates
            LEFT JOIN intern AS i
                ON pt.doc_ID = i.doc_ID
            LEFT JOIN doctors d
                ON i.doc_ID = d.doc_ID
        GROUP BY last_7_days.dates,i.doc_ID
        ORDER BY last_7_days.dates ASC, amount DESC;
    END;

