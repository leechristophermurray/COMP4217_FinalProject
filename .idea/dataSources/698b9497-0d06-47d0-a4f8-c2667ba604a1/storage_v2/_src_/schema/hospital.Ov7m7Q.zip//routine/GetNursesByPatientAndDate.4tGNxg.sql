create
    definer = root@localhost procedure GetNursesByPatientAndDate(IN start_date date, IN end_date date, IN patID int)
BEGIN
        SELECT
               n.nurse_ID,
               fname,
               lname,
               gen_name,
               dosage,
               date_time
        FROM Nurses AS n
        JOIN administers AS a
            ON n.nurse_ID = a.nurse_ID
        JOIN medication m on a.med_ID = m.med_ID
        WHERE (date_time BETWEEN
                    start_date AND end_date)
            AND pat_ID = patID;
    END;

