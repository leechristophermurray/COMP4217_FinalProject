create
    definer = root@localhost procedure GetNursesByPatientAndDate(IN start_date date, IN end_date date, IN patID int)
BEGIN
        SELECT
               nurse_ID,
               fname,
               lname
        FROM Nurses
            WHERE nurse_id IN(
                    SELECT
                           nurse_id
                    FROM administers
                    WHERE (dates BETWEEN
                                start_date AND end_date)
                        AND pat_ID = patID);
    END;

