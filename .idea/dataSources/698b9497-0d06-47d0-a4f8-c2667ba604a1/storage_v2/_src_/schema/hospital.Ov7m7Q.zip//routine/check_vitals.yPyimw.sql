create
    definer = root@localhost procedure check_vitals(IN nurseID int, IN patID int, IN temp int, IN pulse_arg int,
                                                    IN bp int, IN resp varchar(500))
BEGIN
	    IF (
	        (SELECT NOT EXISTS(
                            SELECT 1
                            FROM hospital.checks AS c
                                 JOIN vitalsigns AS v
                                    ON c.nurse_ID = nurseID
                                    AND c.vitals_ID = v.vitals_ID
                                 JOIN belongs_to AS bt
                                     ON bt.pat_ID = patId
                        )
           )
	        OR
           (SELECT EXISTS(
                           SELECT 1
                            FROM hospital.checks AS c
                                 JOIN vitalsigns AS v
                                    ON c.nurse_ID = nurseID
                                    AND c.vitals_ID = v.vitals_ID
                                    AND c.dates < CURRENT_DATE() - INTERVAL 1 DAY
                                 JOIN belongs_to AS bt
                                     ON bt.pat_ID = patId
                       )
           )
	    )
	    THEN

            INSERT INTO  VitalSigns VALUES (NULL, temp, pulse_arg, bp, resp);
            SET @vitalID = (SELECT LAST_INSERT_ID());
            INSERT INTO belongs_to VALUES (patID, @vitalID);
            INSERT INTO checks VALUES ( nurseID, @vitalID, CURRENT_DATE());

        END IF;

    END;

