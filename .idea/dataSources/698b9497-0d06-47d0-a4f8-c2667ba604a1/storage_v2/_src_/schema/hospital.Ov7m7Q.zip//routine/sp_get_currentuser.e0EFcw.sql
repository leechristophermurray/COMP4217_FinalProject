create
    definer = root@localhost procedure sp_get_currentuser(IN username varchar(100))
BEGIN
        SELECT * FROM
            (SELECT
               CONCAT(fname,lname) AS usr,
                doc_ID AS cuid,
               fname,
               lname,
               'Doctor' AS role
            FROM doctors
            UNION
            SELECT
               CONCAT(fname,lname) AS usr,
                    nurse_ID AS cuid,
                   fname,
                   lname,
                   'Nurse' AS role
            FROM nurses
            UNION
            SELECT
               CONCAT(fname,lname) AS usr,
                    sec_ID AS cuid,
                   fname,
                   lname,
                   'Secretary' AS role
            FROM secretaries) AS usrs
        WHERE LOCATE(usrs.usr,username) != 0;
    END;

