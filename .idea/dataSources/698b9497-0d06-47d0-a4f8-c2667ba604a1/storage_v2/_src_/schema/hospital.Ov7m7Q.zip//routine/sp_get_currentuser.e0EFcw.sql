create
    definer = root@localhost procedure sp_get_currentuser(IN username varchar(100))
BEGIN
        SELECT * FROM
            (SELECT
               CONCAT(fname,lname) AS usr,
               fname,
               lname,
               'Doctor' AS role
            FROM doctors
            UNION
            SELECT
               CONCAT(fname,lname) AS usr,
                   fname,
                   lname,
                   'Nurse' AS role
            FROM nurses
            UNION
            SELECT
               CONCAT(fname,lname) AS usr,
                   fname,
                   lname,
                   'Secretary' AS role
            FROM secretaries) AS usrs
        WHERE LOCATE(usrs.usr,username) != 0;
    END;

