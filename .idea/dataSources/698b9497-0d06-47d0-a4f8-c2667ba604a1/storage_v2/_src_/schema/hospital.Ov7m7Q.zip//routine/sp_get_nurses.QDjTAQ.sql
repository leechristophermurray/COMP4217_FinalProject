create
    definer = root@localhost procedure sp_get_nurses()
BEGIN
        SELECT
            fname                                               # tuple[0]
            ,lname                                              # tuple[1]
        FROM Nurses;
    END;

