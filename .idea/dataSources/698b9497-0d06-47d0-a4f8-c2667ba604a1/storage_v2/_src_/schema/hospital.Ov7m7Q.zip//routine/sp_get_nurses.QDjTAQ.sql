create
    definer = root@localhost procedure sp_get_nurses()
BEGIN
        SELECT
            name                                               # tuple[0]
            ,lname                                              # tuple[1]
        FROM Nurses;
    END;

