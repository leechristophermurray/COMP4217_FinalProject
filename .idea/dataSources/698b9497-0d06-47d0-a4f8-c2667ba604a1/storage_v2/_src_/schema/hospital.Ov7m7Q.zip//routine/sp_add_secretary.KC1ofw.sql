create
    definer = root@localhost procedure sp_add_secretary(IN fname varchar(100), IN lname varchar(100), IN dob date,
                                                        IN address varchar(500), IN phone int)
BEGIN
        SET @username = CONCAT(fname,lname);
        SET @password = CONCAT(fname,lname);

        SET @sql = CONCAT('GRANT SELECT,INSERT ON HOSPITAL.* to \'',@username,'\'@\'%\' IDENTIFIED BY \'',@password,'\'');
        PREPARE stmt from @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        INSERT INTO Secretaries VALUES (NULL, fname, lname, dob, address, phone);
    END;

