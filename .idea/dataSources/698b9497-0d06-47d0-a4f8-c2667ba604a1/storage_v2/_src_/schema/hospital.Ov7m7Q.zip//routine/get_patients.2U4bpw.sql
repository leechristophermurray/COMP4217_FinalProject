create
    definer = root@localhost procedure get_patients(IN q varchar(100))
BEGIN
        SELECT
               pat_ID,
               fname,
               lname,
               dob,
               address,
               phone
        FROM Patients
        WHERE LOCATE(q, fname)
            OR LOCATE(q, lname)
            OR LOCATE(q, CONCAT(fname, ' ', lname))
            OR LOCATE(q, pat_ID)
        ORDER BY RAND()
        LIMIT 30;

    END;

