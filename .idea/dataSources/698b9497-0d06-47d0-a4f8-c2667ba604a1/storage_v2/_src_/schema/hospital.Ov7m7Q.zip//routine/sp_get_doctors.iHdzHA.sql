create
    definer = root@localhost procedure sp_get_doctors()
BEGIN
        SELECT
            fname
            ,lname
        FROM Doctors;
    END;

