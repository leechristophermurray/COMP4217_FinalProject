create
    definer = root@localhost procedure sp_get_doctors()
BEGIN
        SELECT
            fname                                               # tuple[0]
            ,lname                                              # tuple[1]
        FROM Doctors;
    END;

