create
    definer = root@localhost procedure GetInternsByMostPatient()
BEGIN
        SELECT
               fname,
               lname,
               Amount
        FROM Doctors
        JOIN (
                SELECT
                       doc_ID,
                       COUNT(pat_ID) AS Amount
                FROM performs_treatment
                GROUP BY doc_ID
                    HAVING COUNT(pat_ID) > (
                            SELECT AVG(pt_avg.Amount)
                            FROM (
                                SELECT COUNT(pat_ID) AS Amount
                                FROM performs_treatment
                                GROUP BY doc_ID
                                ) AS pt_avg
                        )
                ) AS h1 ON Doctors.doc_ID = h1.doc_ID;
    END;

