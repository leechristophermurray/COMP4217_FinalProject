create
    definer = root@localhost procedure GetInternsByMostPatient()
BEGIN
        SELECT
               fname,
               lname
        FROM Doctors
            WHERE doc_ID IN(
                    SELECT
                           Newb.doc_ID
                    FROM Intern AS Newb,
                         performs_treatment AS Help
                    WHERE Newb.doc_ID = Help.doc_ID
                        AND Help.doc_ID IN(
                                SELECT
                                       doc_ID
                                FROM performs_treatment
                                GROUP BY doc_ID
                                    HAVING COUNT(pat_ID) > (
                                            SELECT AVG(pt_avg.Amount)
                                            FROM (
                                                SELECT COUNT(pat_ID) AS Amount
                                                FROM performs_treatment
                                                GROUP BY doc_ID
                                                ) AS pt_avg
                                        )
                            )
                );
    END;

