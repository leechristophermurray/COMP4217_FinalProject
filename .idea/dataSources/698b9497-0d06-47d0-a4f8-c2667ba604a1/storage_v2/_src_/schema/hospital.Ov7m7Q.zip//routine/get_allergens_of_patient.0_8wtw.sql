create
    definer = root@localhost procedure get_allergens_of_patient(IN patID int)
BEGIN
        SELECT aw.allergy_ID        AS AllergenID,
               'Miscellaneous'      AS AllergenType,
               a.name               AS Allergen
        FROM patients AS p
             JOIN afflicted_with aw ON p.pat_ID = aw.pat_ID
             JOIN otherallergies AS a ON a.allergy_ID = aw.allergy_ID
        WHERE p.pat_ID = patID

        UNION

        SELECT  at.med_ID           AS AllergenID,
               'Medication'         AS AllergenType,
               m.gen_name           AS Allergen
        FROM patients AS p
             JOIN allergic_to at ON p.pat_ID = at.pat_ID
             JOIN medication AS m ON m.med_ID = at.med_ID
        WHERE p.pat_ID = patID;
    END;

