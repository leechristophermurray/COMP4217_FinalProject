create
    definer = root@localhost procedure sp_get_currentuser()
BEGIN
        SELECT SESSION_USER();
    END;

