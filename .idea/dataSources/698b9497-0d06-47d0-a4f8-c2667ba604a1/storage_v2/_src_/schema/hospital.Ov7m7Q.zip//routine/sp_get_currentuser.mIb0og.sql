create
    definer = root@localhost procedure sp_get_currentuser()
BEGIN
        SELECT
               User,
               Role
        FROM mysql.roles_mapping
        WHERE CONCAT(User,'@',Host)
                  LIKE CURRENT_USER();
    END;

