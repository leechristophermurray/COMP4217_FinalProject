create
    definer = root@localhost procedure make_diagnosis(IN docID int, IN patID int, IN icdID int,
                                                      IN icdDesc varchar(1000), IN icdname varchar(100),
                                                      IN specifics varchar(500))
BEGIN
	    IF (
	        (SELECT NOT EXISTS(
                            SELECT 1
                            FROM hospital.makes_diagnosis AS md
                                     JOIN diagnosis AS d
                                         ON md.diag_ID = d.diag_ID
                            WHERE md.doc_ID = docID
                              AND md.pat_ID = patId
                              AND d.icd_ID = icdID
                        )
           )
	        OR
           (SELECT EXISTS(
                           SELECT 1
                           FROM hospital.makes_diagnosis AS md
                                    JOIN diagnosis AS d
                                         ON md.diag_ID = d.diag_ID
                           WHERE md.doc_ID = docID
                             AND md.pat_ID = patId
                             AND d.icd_ID = icdID
                             AND md.dates < CURRENT_DATE() - INTERVAL 1 WEEK
                       )
           )
	    )
	    THEN

            INSERT INTO  diagnosis VALUES (NULL, icdID, icdDesc, icdname, specifics);
            SET @diagID = (SELECT LAST_INSERT_ID());
            INSERT INTO makes_diagnosis VALUES (docID, @diagID, patID, CURRENT_DATE());

        END IF;

    END;

